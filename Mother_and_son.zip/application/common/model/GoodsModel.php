<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/14
 * Time: 11:21
 */
namespace app\common\model;
use think\Model;
use think\Validate;

class GoodsModel extends Model
{
    protected $table = 'mother_goods';

    protected $store_id=0;
    //验证规则
    protected $rule = [
        "goods_name"=> 'require|max:255',//商品名称
        "goods_class"=> 'number|max:10',//商品分类
        "goods_type"=> 'number|max:3',//商品类型  1：视频，2：活动，3:线下课程，4：线下实物，5：旅游
        "goods_desc"=> 'max:255',//配置描述
        "store_id"=> 'store_id|max:10',//状态：1：启用2禁用
        "old_price"=> 'float',//
        "new_price"=> 'float',//
        "basic"=> 'number',//
        "sales"=> 'number',//
        "disseminate"=> 'max:255',//
        "cover"=> 'max:255',//
        "pic"=> 'max:1000',//
        "freight_tpl_id"=> 'number',//
        "freight_price"=> 'float',//
        "content"=> 'max:64000',//
        "status"=> 'number',//
        "stock"=> 'number',//
        "create_time"=> 'number|max:10',//
        "update_time"=> 'number|max:10',//
    ];



    public function initialize(){
        parent::initialize();
    }
    /**
     * 关联分类
    */
    public function Classm(){
        return $this->hasOne('ClassModel','id',"goods_class");
    }
    //设置店铺id
    public function setStore($store_id){
        $this->store_id=$store_id;
    }

    /**
     * 根据页码查询数据
    */
    public function getlistbypage($page=1)
    {
        $list=self::with("Classm")//关联商品分类
            ->where(array("store_id"=>$this->store_id,"status"=>array("egt",0)))
            ->order('create_time', 'desc')
            ->paginate(10,false,array("page"=>$page));
        return $list;
    }






}