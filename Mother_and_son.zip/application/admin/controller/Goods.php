<?php
namespace app\admin\controller;
use app\common\model\Class_m;
use app\common\model\ClassModel;
use app\common\model\Goods_model;
use app\common\model\GoodsModel;

/**
 * 商品
 * lin
 * 2019-02-18
*/

class Goods extends Base
{
    public function _initialize(){
        parent::_initialize();
    }

    //--------商品分类（开始）------
    /**
     * 商品分类
    */
    public function goods_class(){
       $class= new ClassModel();
        $class->setpage(1);
        $list=$class->getlistByparent();
        $this->assign("class",$list);

        return view("class");
    }
    //--------商品分类（结束）------




    /***
     *商品列表
    */
    public function goods_list(){
        $goods=new GoodsModel();
        $goods->getlistbypage(1);
        return view("list");
    }


}
