<?php
/**
 * Created by PhpStorm.
 * User: Lin
 * Date: 2019/2/14
 * Time: 9:57
 */

namespace app\api\controller;

use app\admin\model\Path;
use app\common\model\SystemModel;
use think\Controller;
use think\Request;

class Base extends  Controller
{

}