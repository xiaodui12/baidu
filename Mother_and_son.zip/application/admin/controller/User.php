<?php
/**
 * 用户
*/
namespace app\admin\controller;


class User extends Base
{
    public function _initialize(){
        parent::_initialize();
    }
    /**
     * 用户列表
    */
    public function lists(){

    }

    /**
     * 用户等级
    */
    public function level(){

    }
}
