<?php
namespace app\admin\controller;

use app\common\model\aliyun;
use app\common\model\MediaModel;
use think\Request;

/**
 *后台视频管理
 * lin
 * 2019-02-18
 */

class Video extends Base
{
    public function _initialize(){
        parent::_initialize();
    }
    public function lists(){
        $page=input("param.page");
        $media=new MediaModel();

        //当有状态值传入设置状态
        $status=input("param.status");
        $status=$status?$status:10;
        if(!empty($status)){
            $media->setstatus($status);
        }

        $list=$media->get_list($page);
        $this->assign("status",$status);
        $this->assign("list",$list);
        return view("list");
    }

    /**
     * 人工审核提交
    */
    public function send_audit()
    {
        //请求信息
        $request = Request::instance();
        //判断是否是post提交
        if(!$request->isPost()){
            $this->error("请求错误");
        }
        $post=$request->post();//post参数
        $aliyun=new aliyun();
        $return_array=$aliyun->send_audit($post["list"]);
        return $return_array;
    }

}
