<?php
namespace app\api\controller;


use app\common\model\xcx;

class Index extends Base
{
    public function _initialize(){
        parent::_initialize();
    }
    public function index()
    {

    }

    /**
     * 用户登录
     * /api.php/index/login.html
     * 参数：
    */
    public function login(){

        $xcx=new xcx();
        $xcx->check_login("12345");
    }
}
